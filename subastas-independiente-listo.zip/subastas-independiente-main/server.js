require('dotenv').config();
const express = require('express');
const session = require('express-session');
const path = require('path');
require('./src/database');
const authRoutes = require('./src/routes/auth');
const productosRoutes = require('./src/routes/productos');
const app = express();
const PORT = Number(process.env.PORT) || 3000;
const SESSION_SECRET = process.env.SESSION_SECRET;
if (!SESSION_SECRET || SESSION_SECRET.length < 32) {
  console.error('No se encontró SESSION_SECRET. Ejecutá iniciar.bat para crear la configuración automáticamente.');
  process.exit(1);
}
app.disable('x-powered-by');
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(session({ name: 'subastas.sid', secret: SESSION_SECRET, resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax', secure: false, maxAge: 1000 * 60 * 60 * 24 * 30 } }));
app.use('/api/auth', authRoutes);
app.use('/api/productos', productosRoutes);
app.use(express.static(path.join(__dirname, 'public'), { index: 'prueba1.html' }));
app.get('/api/health', (_req, res) => res.json({ ok: true }));
app.use((req, res) => req.path.startsWith('/api/') ? res.status(404).json({ error: 'No se encontró esa función.' }) : res.status(404).send('Página no encontrada.'));
app.listen(PORT, () => console.log(`Subastas Independiente disponible en http://localhost:${PORT}`));
