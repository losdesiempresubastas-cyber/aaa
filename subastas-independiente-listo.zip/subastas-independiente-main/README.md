# Subastas Independiente

Proyecto escolar con HTML, CSS, JavaScript, Node.js y SQLite. Se ejecuta localmente en Windows.

## Requisitos
- Windows 10/11.
- Node.js 20 o superior (LTS recomendado).
- Internet solamente la primera vez, para instalar las dependencias.

## Cómo iniciarlo
1. Descomprimí la carpeta completa.
2. Hacé doble clic en `iniciar.bat`.
3. La primera vez se instalan las dependencias y se crea `.env` automáticamente.
4. Se abre el navegador en `http://localhost:3000`.
5. Dejá abierta la ventana negra llamada **Subastas Independiente - Servidor** mientras uses la página.
6. Para apagar el servidor, cerrá esa ventana.

No abras los HTML haciendo doble clic: para que funcionen el registro, el inicio de sesión y la base de datos, entrá siempre por `http://localhost:3000`.

## Dónde se guardan los datos
- `data/subastas.db`: único archivo de base de datos. Contiene usuarios, productos, carrito y favoritos.
- `public/uploads/`: imágenes subidas por los usuarios.
- `public/`: páginas, estilos, scripts e imágenes originales.
- `src/`: servidor, conexión SQLite y rutas de la API.

La base utiliza el modo SQLite `DELETE` para que los datos queden en un solo archivo fácil de trasladar. Al iniciar, el programa crea las tablas que falten y agrega la columna `direccion` si se trata de una base anterior, sin borrar los datos existentes. El catálogo original de 25 productos se agrega solamente si falta.

## Cómo compartir los datos mediante GitHub (IMPORTANTE)
Este proyecto no sincroniza datos en tiempo real. GitHub guarda una copia del archivo de base de datos para que los compañeros puedan descargar la versión actualizada.

**Para subir los cambios:**
1. Terminá de usar la página.
2. Cerrá la ventana **Subastas Independiente - Servidor**. No copies la base mientras el servidor está funcionando.
3. En GitHub, abrí el repositorio y elegí **Add file > Upload files**.
4. Subí los archivos de código que modificaste, `data/subastas.db` y las imágenes nuevas de `public/uploads/`. Conservá las mismas rutas y carpetas.
5. Confirmá los cambios en GitHub.

**Para continuar en otra computadora:**
1. Descargá el ZIP más nuevo del repositorio.
2. Descomprimilo en una carpeta nueva (o reemplazá la copia anterior después de guardar cualquier cambio local).
3. Ejecutá `iniciar.bat`.

**Regla del grupo:** una sola persona debe trabajar con la base compartida por vez. Si dos compañeros descargan el proyecto y modifican cada uno su propia `subastas.db`, GitHub no puede combinar automáticamente esos registros. Antes de empezar, descarguen la última versión; al terminar, suban la base actualizada y avisen al resto. Nunca suban una base antigua encima de una más nueva.

## Funciones disponibles
- Registro e inicio/cierre de sesión.
- Perfil con nombre, apellido, fecha de nacimiento, email y dirección.
- Catálogo original de 25 productos.
- Publicación de artículos con imagen y precio.
- Productos publicados visibles en el catálogo para todos los que usen la misma base actualizada.
- Favoritos por usuario.
- Carrito por usuario y cálculo del total.
- Perfil con listado de artículos publicados por ese usuario.

## Archivos que NO se deben subir
- `node_modules/`: se instala automáticamente con `npm ci`.
- `.env`: contiene una clave local de sesión y se crea automáticamente.
- No borres ni reemplaces `data/subastas.db` si querés conservar los datos.

Este proyecto es para uso escolar con datos de prueba. No carguen datos personales reales ni utilicen contraseñas que usen en otras cuentas, especialmente si el repositorio es público.
