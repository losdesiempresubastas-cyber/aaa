const formatoPrecio = n => '$' + Number(n).toLocaleString('es-AR', {maximumFractionDigits:2});
async function api(url, opciones={}) {
  const r = await fetch(url, {credentials:'same-origin', ...opciones});
  const datos = await r.json().catch(()=>({}));
  if (!r.ok) throw new Error(datos.error || 'Ocurrió un error.');
  return datos;
}
function tarjeta(p, tipo='mercado') {
  const div=document.createElement('article'); div.className='producto';
  const img=document.createElement('img'); img.src=p.imagen || 'fotos/Compras.PNG'; img.alt=p.nombre;
  const titulo=document.createElement('h3'); titulo.textContent=p.nombre;
  const precio=document.createElement('p'); precio.className='precio'; precio.textContent=formatoPrecio(p.precio);
  const vendedor=document.createElement('p'); vendedor.textContent='Publicado por: '+(p.vendedor || 'Usuario');
  const acciones=document.createElement('div'); acciones.className='acciones';
  if(tipo==='mercado'){
    const carrito=document.createElement('button'); carrito.className='boton'; carrito.textContent='Agregar al carrito'; carrito.onclick=async()=>{try{await api('/api/productos/carrito/'+p.id,{method:'POST'});alert('Agregado al carrito.')}catch(e){alert(e.message);if(e.message.includes('sesión'))location.href='login.html'}};
    const favorito=document.createElement('button'); favorito.className='boton secundario'; favorito.textContent='♡ Favoritos'; favorito.onclick=async()=>{try{await api('/api/productos/favoritos/'+p.id,{method:'POST'});alert('Agregado a favoritos.')}catch(e){alert(e.message);if(e.message.includes('sesión'))location.href='login.html'}};
    acciones.append(carrito,favorito);
  } else {
    const quitar=document.createElement('button'); quitar.className='boton secundario'; quitar.textContent='Quitar'; quitar.onclick=async()=>{try{await api('/api/productos/'+tipo+'/'+p.id,{method:'DELETE'});cargarLista()}catch(e){alert(e.message)}}; acciones.append(quitar);
    if(tipo==='carrito'){const cantidad=document.createElement('p');cantidad.textContent='Cantidad: '+p.cantidad;acciones.append(cantidad)}
  }
  div.append(img,titulo,precio,vendedor,acciones); return div;
}
async function cargarMercado(){
  const cont=document.getElementById('productos');
  try{const r=await api('/api/productos');cont.replaceChildren();if(!r.productos.length){cont.innerHTML='<p class="vacio">Todavía no hay artículos publicados. ¡Podés ser el primero!</p>';return}r.productos.forEach(p=>cont.append(tarjeta(p)))}catch(e){cont.textContent=e.message}
}
async function cargarLista(){
  const tipo=document.body.dataset.lista, cont=document.getElementById('productos'), total=document.getElementById('total');
  try{const r=await api('/api/productos/'+tipo);cont.replaceChildren();if(!r.productos.length){cont.innerHTML='<p class="vacio">Todavía no tenés artículos acá.</p>'}else r.productos.forEach(p=>cont.append(tarjeta(p,tipo)));if(total)total.textContent='Total: '+formatoPrecio(r.total||0)}catch(e){cont.textContent=e.message;if(e.message.includes('sesión'))setTimeout(()=>location.href='login.html',900)}
}
