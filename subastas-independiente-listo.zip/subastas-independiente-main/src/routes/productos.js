const express = require('express');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const db = require('../database');
const router = express.Router();
const carpeta = path.join(__dirname, '..', '..', 'public', 'uploads');
fs.mkdirSync(carpeta, { recursive: true });
const almacenamiento = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, carpeta),
  filename: (_req, file, cb) => cb(null, Date.now() + '-' + Math.round(Math.random() * 1e9) + path.extname(file.originalname).toLowerCase())
});
const subir = multer({ storage: almacenamiento, limits: { fileSize: 5 * 1024 * 1024 }, fileFilter: (_req, file, cb) => {
  if (['image/jpeg', 'image/png', 'image/webp', 'image/gif'].includes(file.mimetype)) cb(null, true);
  else cb(new Error('La imagen debe ser JPG, PNG, WEBP o GIF.'));
} });
function sesion(req, res, next) { if (!req.session.usuarioId) return res.status(401).json({ error: 'Iniciá sesión para hacer eso.' }); next(); }
function listado(where = '', params = []) {
  return db.prepare(`SELECT p.id, p.nombre, p.descripcion, p.precio_inicial AS precio, p.imagen, p.creado_en,
    u.nombre || ' ' || u.apellido AS vendedor FROM productos p JOIN usuarios u ON u.id=p.usuario_id ${where} ORDER BY p.id DESC`).all(...params);
}
router.get('/', (_req, res) => res.json({ productos: listado("WHERE p.estado='activo'") }));
router.get('/mis-publicaciones', sesion, (req, res) => {
  const productos = listado("WHERE p.estado='activo' AND p.usuario_id=?", [req.session.usuarioId]);
  res.json({ productos });
});
router.post('/', sesion, (req, res, next) => subir.single('imagen')(req, res, err => {
  if (err) return res.status(400).json({ error: err.message || 'No se pudo subir la imagen.' });
  next();
}), (req, res) => {
  const nombre = String(req.body.titulo || '').trim();
  const precio = Number(req.body.precio);
  if (!nombre || nombre.length > 100 || !Number.isFinite(precio) || precio < 0 || !req.file) {
    if (req.file) fs.unlink(req.file.path, () => {});
    return res.status(400).json({ error: 'Completá título, precio válido e imagen.' });
  }
  const imagen = '/uploads/' + req.file.filename;
  const r = db.prepare("INSERT INTO productos (usuario_id,nombre,descripcion,precio_inicial,imagen,estado) VALUES (?,?, '', ?, ?, 'activo')")
    .run(req.session.usuarioId, nombre, precio, imagen);
  res.status(201).json({ mensaje: 'Artículo publicado.', producto: listado('WHERE p.id=?', [r.lastInsertRowid])[0] });
});
router.get('/favoritos', sesion, (req, res) => {
  const productos = db.prepare(`SELECT p.id,p.nombre,p.precio_inicial AS precio,p.imagen,u.nombre || ' ' || u.apellido AS vendedor
    FROM favoritos f JOIN productos p ON p.id=f.producto_id JOIN usuarios u ON u.id=p.usuario_id WHERE f.usuario_id=? ORDER BY f.creado_en DESC`).all(req.session.usuarioId);
  res.json({ productos });
});
router.post('/favoritos/:id', sesion, (req, res) => {
  const id = Number(req.params.id);
  if (!db.prepare('SELECT id FROM productos WHERE id=?').get(id)) return res.status(404).json({ error: 'Artículo no encontrado.' });
  db.prepare('INSERT OR IGNORE INTO favoritos (usuario_id,producto_id) VALUES (?,?)').run(req.session.usuarioId, id);
  res.json({ mensaje: 'Agregado a favoritos.' });
});
router.delete('/favoritos/:id', sesion, (req, res) => {
  db.prepare('DELETE FROM favoritos WHERE usuario_id=? AND producto_id=?').run(req.session.usuarioId, Number(req.params.id)); res.json({ mensaje: 'Quitado de favoritos.' });
});
router.get('/carrito', sesion, (req, res) => {
  const productos = db.prepare(`SELECT p.id,p.nombre,p.precio_inicial AS precio,p.imagen,c.cantidad,u.nombre || ' ' || u.apellido AS vendedor
    FROM carrito c JOIN productos p ON p.id=c.producto_id JOIN usuarios u ON u.id=p.usuario_id WHERE c.usuario_id=? ORDER BY c.agregado_en DESC`).all(req.session.usuarioId);
  const total = productos.reduce((s, p) => s + p.precio * p.cantidad, 0);
  res.json({ productos, total });
});
router.post('/carrito/:id', sesion, (req, res) => {
  const id = Number(req.params.id);
  if (!db.prepare('SELECT id FROM productos WHERE id=?').get(id)) return res.status(404).json({ error: 'Artículo no encontrado.' });
  db.prepare(`INSERT INTO carrito (usuario_id,producto_id,cantidad) VALUES (?,?,1)
    ON CONFLICT(usuario_id,producto_id) DO UPDATE SET cantidad=cantidad+1`).run(req.session.usuarioId, id);
  res.json({ mensaje: 'Agregado al carrito.' });
});
router.delete('/carrito/:id', sesion, (req, res) => {
  db.prepare('DELETE FROM carrito WHERE usuario_id=? AND producto_id=?').run(req.session.usuarioId, Number(req.params.id)); res.json({ mensaje: 'Quitado del carrito.' });
});
module.exports = router;
