const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('../database');
const router = express.Router();
const texto = v => typeof v === 'string' ? v.trim() : '';

function usuarioPublico(u) {
  return { id: u.id, nombre: u.nombre, apellido: u.apellido, fecha_nacimiento: u.fecha_nacimiento, mail: u.mail, direccion: u.direccion || '' };
}
function requiereSesion(req, res, next) {
  if (!req.session.usuarioId) return res.status(401).json({ error: 'Primero iniciá sesión.' });
  next();
}

router.post('/registro', (req, res) => {
  const nombre = texto(req.body.nombre), apellido = texto(req.body.apellido);
  const fecha = texto(req.body.fecha_nacimiento), mail = texto(req.body.mail).toLowerCase();
  const direccion = texto(req.body.direccion);
  const clave = typeof req.body.clave === 'string' ? req.body.clave : '';
  if (!nombre || !apellido || !fecha || !mail || !clave) return res.status(400).json({ error: 'Completá todos los campos.' });
  try {
    // Para el proyecto escolar, la contraseña se guarda como texto simple.
    // clave_hash se completa también para poder conservar bases de datos anteriores.
    const result = db.prepare(`INSERT INTO usuarios (nombre, apellido, fecha_nacimiento, mail, clave_hash, clave, direccion)
      VALUES (?, ?, ?, ?, ?, ?, ?)`).run(nombre, apellido, fecha, mail, clave, clave, direccion);
    req.session.usuarioId = Number(result.lastInsertRowid);
    res.status(201).json({ mensaje: 'Cuenta creada.', usuario: usuarioPublico(db.prepare('SELECT * FROM usuarios WHERE id=?').get(req.session.usuarioId)) });
  } catch (e) {
    if (e.code === 'SQLITE_CONSTRAINT_UNIQUE') return res.status(409).json({ error: 'Ese email ya está registrado.' });
    console.error(e); res.status(500).json({ error: 'No se pudo crear la cuenta.' });
  }
});

router.post('/login', (req, res) => {
  const mail = texto(req.body.mail).toLowerCase();
  const clave = typeof req.body.clave === 'string' ? req.body.clave : '';
  const u = db.prepare('SELECT * FROM usuarios WHERE mail = ?').get(mail);
  // Las cuentas nuevas comparan texto simple. Se permite entrar a cuentas viejas con hash.
  const coincide = u && (u.clave !== null && u.clave !== undefined ? u.clave === clave : bcrypt.compareSync(clave, u.clave_hash));
  if (!coincide) return res.status(401).json({ error: 'Email o contraseña incorrectos.' });
  req.session.usuarioId = u.id;
  res.json({ mensaje: 'Sesión iniciada.', usuario: usuarioPublico(u) });
});
router.get('/me', requiereSesion, (req, res) => {
  const u = db.prepare('SELECT * FROM usuarios WHERE id=?').get(req.session.usuarioId);
  if (!u) return res.status(401).json({ error: 'No se encontró el usuario.' });
  res.json({ usuario: usuarioPublico(u) });
});
router.post('/logout', (req, res) => {
  req.session.destroy(() => { res.clearCookie('subastas.sid'); res.json({ mensaje: 'Sesión cerrada.' }); });
});
module.exports = router;
