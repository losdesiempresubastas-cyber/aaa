const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');

const dataDir = path.join(__dirname, '..', 'data');
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, 'subastas.db'));
db.pragma('foreign_keys = ON');
// Modo DELETE: mantiene la base en un único archivo fácil de copiar y subir a GitHub.
db.pragma('journal_mode = DELETE');

db.exec(`
  CREATE TABLE IF NOT EXISTS usuarios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL,
    apellido TEXT NOT NULL,
    fecha_nacimiento TEXT NOT NULL,
    mail TEXT NOT NULL UNIQUE COLLATE NOCASE,
    clave_hash TEXT NOT NULL,
    direccion TEXT NOT NULL DEFAULT '',
    creado_en TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS productos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    usuario_id INTEGER NOT NULL,
    nombre TEXT NOT NULL,
    descripcion TEXT DEFAULT '',
    precio_inicial REAL NOT NULL DEFAULT 0 CHECK (precio_inicial >= 0),
    imagen TEXT,
    estado TEXT NOT NULL DEFAULT 'activo',
    creado_en TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
  );
  CREATE TABLE IF NOT EXISTS favoritos (
    usuario_id INTEGER NOT NULL,
    producto_id INTEGER NOT NULL,
    creado_en TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (usuario_id, producto_id),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (producto_id) REFERENCES productos(id) ON DELETE CASCADE
  );
  CREATE TABLE IF NOT EXISTS carrito (
    usuario_id INTEGER NOT NULL,
    producto_id INTEGER NOT NULL,
    cantidad INTEGER NOT NULL DEFAULT 1 CHECK (cantidad > 0),
    agregado_en TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (usuario_id, producto_id),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (producto_id) REFERENCES productos(id) ON DELETE CASCADE
  );
`);

// Columna simple para las contraseñas del proyecto escolar. Si la base ya existía,
// la agrega sin borrar los usuarios anteriores.
const columnasUsuario = db.prepare('PRAGMA table_info(usuarios)').all().map(c => c.name);
if (!columnasUsuario.includes('clave')) db.exec('ALTER TABLE usuarios ADD COLUMN clave TEXT');
if (!columnasUsuario.includes('direccion')) db.exec("ALTER TABLE usuarios ADD COLUMN direccion TEXT NOT NULL DEFAULT ''");



// Catálogo original de Compras.html. Se agrega a la base una sola vez por producto.
// Así los productos que ya estaban en la tienda siguen visibles y también pueden usarse
// con favoritos y carrito. Los nuevos artículos se guardan en la misma tabla.
const catalogoOriginal = [
  {
    "nombre": "Campera 1",
    "imagen": "/fotos/CAMPERA.jpg",
    "precio": 149999.0
  },
  {
    "nombre": "Campera 2",
    "imagen": "/fotos/CAMPERA2.jpg",
    "precio": 179999.0
  },
  {
    "nombre": "Campera 3",
    "imagen": "/fotos/CAMPERA3.jpg",
    "precio": 165000.0
  },
  {
    "nombre": "Camperón 1",
    "imagen": "/fotos/CAMPERON.jpg",
    "precio": 165000.0
  },
  {
    "nombre": "Camperón 2",
    "imagen": "/fotos/CAMPERON2.jpg",
    "precio": 170000.0
  },
  {
    "nombre": "Remera 1",
    "imagen": "/fotos/REMERA1.jpg",
    "precio": 70000.0
  },
  {
    "nombre": "Remera 2",
    "imagen": "/fotos/REMERA2.jpg",
    "precio": 90000.0
  },
  {
    "nombre": "Remera 3",
    "imagen": "/fotos/REMERA3.jpg",
    "precio": 100000.0
  },
  {
    "nombre": "Remera 4",
    "imagen": "/fotos/REMERA4.jpg",
    "precio": 120000.0
  },
  {
    "nombre": "Remera 5",
    "imagen": "/fotos/REMERA5.jpg",
    "precio": 130000.0
  },
  {
    "nombre": "Remera 6",
    "imagen": "/fotos/REMERA6.jpg",
    "precio": 97000.0
  },
  {
    "nombre": "Remera 7",
    "imagen": "/fotos/REMERA7.jpg",
    "precio": 66999.0
  },
  {
    "nombre": "Remera 8",
    "imagen": "/fotos/REMERA9.jpg",
    "precio": 117000.0
  },
  {
    "nombre": "Remera 9",
    "imagen": "/fotos/REMERA10.jpg",
    "precio": 100000.0
  },
  {
    "nombre": "Remera 10",
    "imagen": "/fotos/REMERA11.jpg",
    "precio": 280000.0
  },
  {
    "nombre": "Remera 11",
    "imagen": "/fotos/REMERA12.jpg",
    "precio": 207000.0
  },
  {
    "nombre": "Short 1",
    "imagen": "/fotos/SHORT1.jpg",
    "precio": 50000.0
  },
  {
    "nombre": "Short 2",
    "imagen": "/fotos/SHORT2.jpg",
    "precio": 55000.0
  },
  {
    "nombre": "Short 3",
    "imagen": "/fotos/SHORT3.jpg",
    "precio": 47999.0
  },
  {
    "nombre": "Short 4",
    "imagen": "/fotos/SHORT4.jpg",
    "precio": 45000.0
  },
  {
    "nombre": "Short 5",
    "imagen": "/fotos/SHORT5.jpg",
    "precio": 44999.0
  },
  {
    "nombre": "Short 7",
    "imagen": "/fotos/SHORT7.jpg",
    "precio": 60000.0
  },
  {
    "nombre": "Short 8",
    "imagen": "/fotos/SHORT8.jpg",
    "precio": 60000.0
  },
  {
    "nombre": "Short 9",
    "imagen": "/fotos/SHORT9.jpg",
    "precio": 80000.0
  },
  {
    "nombre": "Pasamontaña",
    "imagen": "/fotos/PASAMONTAÑA.jpg",
    "precio": 37999.0
  }
];
const usuarioCatalogo = db.prepare("SELECT id FROM usuarios WHERE mail = ?").get('catalogo@independiente.local') || (() => {
  const r = db.prepare(`INSERT INTO usuarios (nombre, apellido, fecha_nacimiento, mail, clave_hash, clave) VALUES (?, ?, ?, ?, ?, ?)`)
    .run('Catálogo', 'Independiente', '2000-01-01', 'catalogo@independiente.local', 'catalogo', 'catalogo');
  return { id: Number(r.lastInsertRowid) };
})();
const buscarProductoCatalogo = db.prepare('SELECT id FROM productos WHERE nombre = ? AND imagen = ?');
const agregarProductoCatalogo = db.prepare("INSERT INTO productos (usuario_id, nombre, descripcion, precio_inicial, imagen, estado) VALUES (?, ?, '', ?, ?, 'activo')");
for (const producto of catalogoOriginal) {
  if (!buscarProductoCatalogo.get(producto.nombre, producto.imagen)) {
    agregarProductoCatalogo.run(usuarioCatalogo.id, producto.nombre, producto.precio, producto.imagen);
  }
}

module.exports = db;
