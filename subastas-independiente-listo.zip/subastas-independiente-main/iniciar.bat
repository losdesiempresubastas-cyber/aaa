@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul

title Subastas Independiente

echo ==========================================
echo     SUBASTAS INDEPENDIENTE - INICIO
echo ==========================================
echo.

where node >nul 2>nul
if errorlevel 1 (
    echo ERROR: No se encontro Node.js instalado.
    echo Instala la version LTS desde https://nodejs.org/ y volve a abrir este archivo.
    echo.
    pause
    exit /b 1
)

for /f "tokens=1 delims=v" %%V in ('node -v') do set NODE_VERSION=%%V
for /f "tokens=1,2 delims=." %%A in ("%NODE_VERSION%") do set NODE_MAJOR=%%A
if %NODE_MAJOR% LSS 20 (
    echo ERROR: Este proyecto necesita Node.js 20 o superior.
    echo Instala la version LTS desde https://nodejs.org/.
    echo.
    pause
    exit /b 1
)

node -e "require('better-sqlite3'); require('express'); require('dotenv'); require('express-session'); require('multer'); require('bcryptjs')" >nul 2>nul
if errorlevel 1 (
    echo Instalando o reparando dependencias. Esto puede tardar unos minutos...
    call npm ci
    if errorlevel 1 (
        echo.
        echo ERROR: No se pudieron instalar las dependencias.
        echo Revisa tu conexion a Internet y volve a ejecutar iniciar.bat.
        pause
        exit /b 1
    )
)

if not exist ".env" (
    echo Creando configuracion local segura...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$secret = [guid]::NewGuid().ToString('N') + [guid]::NewGuid().ToString('N'); Set-Content -Path '.env' -Value ('SESSION_SECRET=' + $secret) -Encoding ascii"
    if errorlevel 1 (
        echo ERROR: No se pudo crear .env automaticamente.
        echo Crea .env copiando .env.example y configura SESSION_SECRET con al menos 32 caracteres aleatorios.
        pause
        exit /b 1
    )
)

echo.
echo El servidor se esta iniciando en otra ventana...
start "Subastas Independiente - Servidor" /D "%~dp0" cmd /k npm start
timeout /t 3 /nobreak >nul
start "" http://localhost:3000
echo.
echo Deja abierta la ventana del servidor mientras uses la pagina.
echo Para detenerlo, cerra la ventana "Subastas Independiente - Servidor".
pause
