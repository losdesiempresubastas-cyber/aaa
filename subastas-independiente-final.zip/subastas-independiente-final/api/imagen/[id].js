// api/imagen/[id].js — Sirve la imagen binaria guardada en MySQL
const { getDb } = require('../../lib/db');

module.exports = async (req, res) => {
  try {
    const id = parseInt(req.query.id, 10);
    if (!id) return res.status(404).end();

    const db = await getDb();
    const [rows] = await db.execute(
      'SELECT imagen_data, imagen_mime FROM productos WHERE id = ?', [id]
    );
    const p = rows[0];
    if (!p || !p.imagen_data) return res.status(404).end();

    res.setHeader('Content-Type', p.imagen_mime || 'application/octet-stream');
    res.setHeader('Cache-Control', 'public, max-age=3600');
    res.end(p.imagen_data);
  } catch (e) {
    console.error(e);
    res.status(500).end();
  }
};
