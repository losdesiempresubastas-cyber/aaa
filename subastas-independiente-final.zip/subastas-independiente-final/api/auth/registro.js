// api/auth/registro.js
const { getDb }              = require('../../lib/db');
const { setSession, publicUser } = require('../../lib/auth');
const { method, error, text }   = require('../../lib/http');

module.exports = async (req, res) => {
  if (!method(req, res, ['POST'])) return;
  try {
    const nombre          = text(req.body?.nombre);
    const apellido        = text(req.body?.apellido);
    const fechaNacimiento = text(req.body?.fecha_nacimiento);
    const mail            = text(req.body?.mail).toLowerCase();
    const direccion       = text(req.body?.direccion);
    const clave           = typeof req.body?.clave === 'string' ? req.body.clave : '';

    if (!nombre || !apellido || !fechaNacimiento || !mail || !clave)
      return res.status(400).json({ error: 'Completá nombre, apellido, fecha de nacimiento, email y contraseña.' });
    if (nombre.length > 80 || apellido.length > 80 || mail.length > 254 || !/^\S+@\S+\.\S+$/.test(mail))
      return res.status(400).json({ error: 'Revisá el nombre, apellido y email.' });

    const db = await getDb();

    // Verificar si el mail ya existe
    const [existe] = await db.execute('SELECT id FROM usuarios WHERE mail = ?', [mail]);
    if (existe.length > 0)
      return res.status(409).json({ error: 'Ese email ya está registrado.' });

    const [result] = await db.execute(
      'INSERT INTO usuarios (nombre, apellido, fecha_nacimiento, mail, direccion, clave) VALUES (?, ?, ?, ?, ?, ?)',
      [nombre, apellido, fechaNacimiento || null, mail, direccion, clave]
    );

    const user = { id: result.insertId, nombre, apellido, fecha_nacimiento: fechaNacimiento, mail, direccion };
    setSession(res, user.id);
    return res.status(201).json({ mensaje: 'Cuenta creada correctamente.', usuario: publicUser(user) });
  } catch (e) {
    if (e.code === 'ER_DUP_ENTRY') return res.status(409).json({ error: 'Ese email ya está registrado.' });
    error(res, e);
  }
};
