// api/auth/perfil.js
const { getDb }                  = require('../../lib/db');
const { requireUser, publicUser } = require('../../lib/auth');
const { method, error, text }     = require('../../lib/http');

module.exports = async (req, res) => {
  if (!method(req, res, ['PATCH'])) return;
  try {
    const db        = await getDb();
    const user      = await requireUser(req, res, db);
    if (!user) return;
    const direccion = text(req.body?.direccion);
    if (direccion.length > 250)
      return res.status(400).json({ error: 'La dirección no puede superar los 250 caracteres.' });
    await db.execute('UPDATE usuarios SET direccion = ? WHERE id = ?', [direccion, user.id]);
    const [rows] = await db.execute('SELECT * FROM usuarios WHERE id = ?', [user.id]);
    res.json({ mensaje: 'Perfil actualizado.', usuario: publicUser(rows[0]) });
  } catch (e) { error(res, e); }
};
