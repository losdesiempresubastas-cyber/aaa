// api/auth/login.js
const { getDb }              = require('../../lib/db');
const { setSession, publicUser } = require('../../lib/auth');
const { method, error, text }   = require('../../lib/http');

module.exports = async (req, res) => {
  if (!method(req, res, ['POST'])) return;
  try {
    const mail  = text(req.body?.mail).toLowerCase();
    const clave = typeof req.body?.clave === 'string' ? req.body.clave : '';

    if (!mail || !clave)
      return res.status(400).json({ error: 'Ingresá tu email y contraseña.' });

    const db = await getDb();
    const [rows] = await db.execute('SELECT * FROM usuarios WHERE mail = ?', [mail]);
    const user = rows[0] || null;

    if (!user || user.clave !== clave)
      return res.status(401).json({ error: 'Email o contraseña incorrectos.' });

    setSession(res, user.id);
    return res.json({ mensaje: 'Sesión iniciada.', usuario: publicUser(user) });
  } catch (e) { error(res, e); }
};
