// api/productos/carrito/index.js — GET carrito del usuario
const { getDb }       = require('../../../lib/db');
const { requireUser } = require('../../../lib/auth');
const { method, error } = require('../../../lib/http');

module.exports = async (req, res) => {
  if (!method(req, res, ['GET'])) return;
  try {
    const db   = await getDb();
    const user = await requireUser(req, res, db);
    if (!user) return;

    const [items] = await db.execute(
      `SELECT p.id, p.nombre, p.precio, p.imagen, p.imagen_data, p.vendedor, c.cantidad
       FROM carrito c
       JOIN productos p ON p.id = c.producto_id
       WHERE c.usuario_id = ? AND p.estado = 'activo'`,
      [user.id]
    );
    const lista = items.map(p => ({
      id:       String(p.id),
      nombre:   p.nombre,
      precio:   p.precio,
      imagen:   p.imagen_data ? `/api/imagen/${p.id}` : p.imagen,
      vendedor: p.vendedor,
      cantidad: p.cantidad || 1
    }));
    const total = lista.reduce((s, p) => s + p.precio * p.cantidad, 0);
    res.json({ productos: lista, total });
  } catch (e) { error(res, e); }
};
