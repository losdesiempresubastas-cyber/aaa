// api/productos/mis-publicaciones.js
const { getDb }       = require('../../lib/db');
const { requireUser } = require('../../lib/auth');
const { method, error } = require('../../lib/http');

module.exports = async (req, res) => {
  if (!method(req, res, ['GET'])) return;
  try {
    const db   = await getDb();
    const user = await requireUser(req, res, db);
    if (!user) return;

    const [rows] = await db.execute(
      `SELECT * FROM productos WHERE usuario_id = ? AND estado = 'activo' ORDER BY creado_en DESC`,
      [user.id]
    );
    res.json({
      productos: rows.map(p => ({
        id:          String(p.id),
        nombre:      p.nombre,
        descripcion: p.descripcion || '',
        precio:      p.precio,
        imagen:      p.imagen_data ? `/api/imagen/${p.id}` : p.imagen,
        vendedor:    p.vendedor,
        creado_en:   p.creado_en
      }))
    });
  } catch (e) { error(res, e); }
};
