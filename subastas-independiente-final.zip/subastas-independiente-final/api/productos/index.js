// api/productos/index.js — GET lista de productos / POST publicar artículo
const { getDb }              = require('../../lib/db');
const { requireUser }        = require('../../lib/auth');
const { method, error, text } = require('../../lib/http');

function publico(p) {
  return {
    id:         String(p.id),
    nombre:     p.nombre,
    descripcion: p.descripcion || '',
    precio:     p.precio,
    imagen:     p.imagen_data ? `/api/imagen/${p.id}` : p.imagen,
    vendedor:   p.vendedor || 'Usuario',
    origen:     p.origen || 'usuario',
    usuario_id: p.usuario_id ? String(p.usuario_id) : null,
    creado_en:  p.creado_en
  };
}

module.exports = async (req, res) => {
  try {
    const db = await getDb();

    if (req.method === 'GET') {
      const [rows] = await db.execute(
        `SELECT * FROM productos WHERE estado = 'activo'
         ORDER BY CASE WHEN origen = 'catalogo-original' THEN 1 ELSE 0 END ASC,
                  creado_en DESC
         LIMIT 300`
      );
      const nuevos    = rows.filter(p => p.origen !== 'catalogo-original');
      const originales = rows.filter(p => p.origen === 'catalogo-original')
                             .sort((a, b) => (a.orden_catalogo || 0) - (b.orden_catalogo || 0));
      return res.json({
        productos: [...nuevos, ...originales].map(publico),
        publicacionesUsuario: nuevos.map(publico)
      });
    }

    if (!method(req, res, ['POST'])) return;

    const user = await requireUser(req, res, db);
    if (!user) return;

    const nombre     = text(req.body?.titulo);
    const descripcion = text(req.body?.descripcion);
    const precio     = Number(req.body?.precio);
    const mime       = text(req.body?.imagenMime);
    const data       = text(req.body?.imagenBase64);

    if (!nombre || nombre.length > 100 || !Number.isFinite(precio) || precio < 0 || precio > 1000000000)
      return res.status(400).json({ error: 'Completá un título y un precio válido.' });
    if (!['image/jpeg', 'image/png', 'image/webp', 'image/gif'].includes(mime))
      return res.status(400).json({ error: 'La imagen debe ser JPG, PNG, WEBP o GIF.' });
    const match = data.match(/^data:(image\/(?:jpeg|png|webp|gif));base64,([A-Za-z0-9+/=]+)$/);
    if (!match || match[1] !== mime)
      return res.status(400).json({ error: 'No se pudo leer la imagen seleccionada.' });
    const bytes = Buffer.from(match[2], 'base64');
    if (!bytes.length || bytes.length > 2 * 1024 * 1024)
      return res.status(400).json({ error: 'La imagen debe pesar como máximo 2 MB.' });

    const [result] = await db.execute(
      `INSERT INTO productos (nombre, descripcion, precio, imagen_data, imagen_mime, usuario_id, vendedor, estado, origen)
       VALUES (?, ?, ?, ?, ?, ?, ?, 'activo', 'usuario')`,
      [nombre, descripcion.slice(0, 1000), precio, bytes, mime, user.id, `${user.nombre} ${user.apellido}`]
    );
    const [rows] = await db.execute('SELECT * FROM productos WHERE id = ?', [result.insertId]);
    return res.status(201).json({ mensaje: 'Artículo publicado correctamente.', producto: publico(rows[0]) });
  } catch (e) { error(res, e); }
};
