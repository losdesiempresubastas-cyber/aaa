// api/productos/[id].js — DELETE eliminar producto propio
const { getDb }       = require('../../lib/db');
const { requireUser } = require('../../lib/auth');
const { method, error } = require('../../lib/http');

module.exports = async (req, res) => {
  if (!method(req, res, ['DELETE'])) return;
  try {
    const db   = await getDb();
    const user = await requireUser(req, res, db);
    if (!user) return;

    const id = parseInt(req.query.id, 10);
    if (!id) return res.status(400).json({ error: 'Artículo inválido.' });

    const [r] = await db.execute(
      `UPDATE productos SET estado = 'eliminado' WHERE id = ? AND usuario_id = ?`,
      [id, user.id]
    );
    if (!r.affectedRows)
      return res.status(404).json({ error: 'No se encontró un artículo tuyo para eliminar.' });

    await db.execute('DELETE FROM carrito   WHERE producto_id = ?', [id]);
    await db.execute('DELETE FROM favoritos WHERE producto_id = ?', [id]);
    res.json({ mensaje: 'Artículo eliminado.' });
  } catch (e) { error(res, e); }
};
