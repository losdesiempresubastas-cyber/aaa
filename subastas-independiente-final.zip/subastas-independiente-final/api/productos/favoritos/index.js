// api/productos/favoritos/index.js — GET favoritos del usuario
const { getDb }       = require('../../../lib/db');
const { requireUser } = require('../../../lib/auth');
const { method, error } = require('../../../lib/http');

module.exports = async (req, res) => {
  if (!method(req, res, ['GET'])) return;
  try {
    const db   = await getDb();
    const user = await requireUser(req, res, db);
    if (!user) return;

    const [rows] = await db.execute(
      `SELECT p.id, p.nombre, p.precio, p.imagen, p.imagen_data, p.vendedor
       FROM favoritos f
       JOIN productos p ON p.id = f.producto_id
       WHERE f.usuario_id = ? AND p.estado = 'activo'
       ORDER BY f.creado_en DESC`,
      [user.id]
    );
    const productos = rows.map(p => ({
      id:       String(p.id),
      nombre:   p.nombre,
      precio:   p.precio,
      imagen:   p.imagen_data ? `/api/imagen/${p.id}` : p.imagen,
      vendedor: p.vendedor
    }));
    res.json({ productos });
  } catch (e) { error(res, e); }
};
