// api/productos/favoritos/[id].js — POST agregar / DELETE quitar de favoritos
const { getDb }       = require('../../../lib/db');
const { requireUser } = require('../../../lib/auth');
const { method, error } = require('../../../lib/http');

module.exports = async (req, res) => {
  if (!method(req, res, ['POST', 'DELETE'])) return;
  try {
    const db   = await getDb();
    const user = await requireUser(req, res, db);
    if (!user) return;

    const id = parseInt(req.query.id, 10);
    if (!id) return res.status(400).json({ error: 'Artículo inválido.' });

    if (req.method === 'POST') {
      const [p] = await db.execute(
        `SELECT id FROM productos WHERE id = ? AND estado = 'activo'`, [id]
      );
      if (!p.length) return res.status(404).json({ error: 'Artículo no encontrado.' });

      await db.execute(
        `INSERT IGNORE INTO favoritos (usuario_id, producto_id) VALUES (?, ?)`,
        [user.id, id]
      );
      return res.json({ mensaje: 'Agregado a favoritos.' });
    }

    await db.execute('DELETE FROM favoritos WHERE usuario_id = ? AND producto_id = ?', [user.id, id]);
    return res.json({ mensaje: 'Quitado de favoritos.' });
  } catch (e) { error(res, e); }
};
