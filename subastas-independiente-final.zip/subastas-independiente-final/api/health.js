// api/health.js — Estado del servidor y la base de datos
const { getDb }         = require('../lib/db');
const { method, error } = require('../lib/http');

module.exports = async (req, res) => {
  if (!method(req, res, ['GET'])) return;
  try {
    const db = await getDb();
    const [[{ total_productos }]] = await db.execute(
      `SELECT COUNT(*) AS total_productos FROM productos WHERE estado = 'activo'`
    );
    const [[{ total_usuarios }]] = await db.execute(
      `SELECT COUNT(*) AS total_usuarios FROM usuarios`
    );
    res.setHeader('Cache-Control', 'no-store');
    res.json({ ok: true, baseDeDatos: 'conectada (MySQL)', productos: total_productos, usuarios: total_usuarios });
  } catch (e) { error(res, e); }
};
