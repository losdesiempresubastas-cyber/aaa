// server.js — Servidor local para Subastas Independiente (MySQL, sin Vercel)
const http = require('http');
const fs   = require('fs');
const path = require('path');
const url  = require('url');

// Cargar variables de entorno desde .env si existe
const envPath = path.join(__dirname, '.env');
if (fs.existsSync(envPath)) {
  fs.readFileSync(envPath, 'utf8').split('\n').forEach(linea => {
    linea = linea.trim();
    if (!linea || linea.startsWith('#')) return;
    const idx = linea.indexOf('=');
    if (idx > 0) {
      const clave = linea.slice(0, idx).trim();
      const valor = linea.slice(idx + 1).trim();
      if (!process.env[clave]) process.env[clave] = valor;
    }
  });
}

const PORT       = process.env.PORT || 3000;
const PUBLIC_DIR = path.join(__dirname, 'public');

const MIME_TYPES = {
  '.html': 'text/html; charset=UTF-8',
  '.css':  'text/css; charset=UTF-8',
  '.js':   'application/javascript; charset=UTF-8',
  '.json': 'application/json; charset=UTF-8',
  '.png':  'image/png',
  '.jpg':  'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.gif':  'image/gif',
  '.ico':  'image/x-icon'
};

// Importar todos los handlers de API
const apiHealth                   = require('./api/health');
const apiAuthRegistro             = require('./api/auth/registro');
const apiAuthLogin                = require('./api/auth/login');
const apiAuthLogout               = require('./api/auth/logout');
const apiAuthMe                   = require('./api/auth/me');
const apiAuthPerfil               = require('./api/auth/perfil');
const apiProductos                = require('./api/productos/index');
const apiProductosId              = require('./api/productos/[id]');
const apiProductosMisPublicaciones = require('./api/productos/mis-publicaciones');
const apiCarrito                  = require('./api/productos/carrito/index');
const apiCarritoId                = require('./api/productos/carrito/[id]');
const apiFavoritos                = require('./api/productos/favoritos/index');
const apiFavoritosId              = require('./api/productos/favoritos/[id]');
const apiImagenId                 = require('./api/imagen/[id]');

// Enrutador de API
function encontrarManejadorApi(pathname) {
  const sub    = pathname.replace(/^\/api\/?/, '').replace(/\/$/, '');
  const partes = sub.split('/').filter(Boolean);
  if (!partes.length) return null;

  if (partes.length === 1 && partes[0] === 'health')
    return { handler: apiHealth, queryParams: {} };

  if (partes[0] === 'auth' && partes.length === 2) {
    const accion = partes[1];
    if (accion === 'registro') return { handler: apiAuthRegistro,  queryParams: {} };
    if (accion === 'login')    return { handler: apiAuthLogin,     queryParams: {} };
    if (accion === 'logout')   return { handler: apiAuthLogout,    queryParams: {} };
    if (accion === 'me')       return { handler: apiAuthMe,        queryParams: {} };
    if (accion === 'perfil')   return { handler: apiAuthPerfil,    queryParams: {} };
  }

  if (partes[0] === 'imagen' && partes.length === 2)
    return { handler: apiImagenId, queryParams: { id: partes[1] } };

  if (partes[0] === 'productos') {
    if (partes[1] === 'carrito') {
      if (partes.length === 2) return { handler: apiCarrito,   queryParams: {} };
      if (partes.length === 3) return { handler: apiCarritoId, queryParams: { id: partes[2] } };
    }
    if (partes[1] === 'favoritos') {
      if (partes.length === 2) return { handler: apiFavoritos,   queryParams: {} };
      if (partes.length === 3) return { handler: apiFavoritosId, queryParams: { id: partes[2] } };
    }
    if (partes[1] === 'mis-publicaciones')
      return { handler: apiProductosMisPublicaciones, queryParams: {} };
    if (partes.length === 1) return { handler: apiProductos,   queryParams: {} };
    if (partes.length === 2) return { handler: apiProductosId, queryParams: { id: partes[1] } };
  }

  return null;
}

const server = http.createServer(async (req, res) => {
  const parsedUrl = url.parse(req.url, true);
  let   pathname  = decodeURIComponent(parsedUrl.pathname);

  // Helpers de Express-like para los handlers
  req.query     = { ...parsedUrl.query };
  res.status    = function (code) { this.statusCode = code; return this; };
  res.json      = function (obj) {
    this.setHeader('Content-Type', 'application/json; charset=UTF-8');
    this.end(JSON.stringify(obj));
    return this;
  };
  res.send      = function (data) {
    if (Buffer.isBuffer(data)) this.end(data);
    else if (typeof data === 'object') this.json(data);
    else this.end(String(data));
    return this;
  };

  // Rutas de API
  if (pathname.startsWith('/api')) {
    const route = encontrarManejadorApi(pathname);
    if (!route) { res.status(404).json({ error: 'Ruta de API no encontrada.' }); return; }
    Object.assign(req.query, route.queryParams);

    const ejecutar = async () => {
      try { await route.handler(req, res); }
      catch (err) {
        console.error('Error en API:', err);
        if (!res.writableEnded) res.status(500).json({ error: err.message || 'Error interno.' });
      }
    };

    if (req.body && typeof req.body === 'object') { ejecutar(); return; }

    let bodyData = '';
    req.on('data', chunk => { bodyData += chunk; });
    req.on('end', async () => {
      try { req.body = bodyData ? JSON.parse(bodyData) : {}; }
      catch { req.body = {}; }
      await ejecutar();
    });
    return;
  }

  // Archivos estáticos desde public/
  if (pathname === '/' || pathname === '') pathname = '/prueba1.html';
  const filePath = path.join(PUBLIC_DIR, pathname);

  fs.stat(filePath, (err, stats) => {
    if (err || !stats.isFile()) {
      const fallback = path.join(PUBLIC_DIR, 'prueba1.html');
      fs.readFile(fallback, (e2, content) => {
        if (e2) { res.writeHead(404); res.end('Página no encontrada.'); return; }
        res.writeHead(200, { 'Content-Type': 'text/html; charset=UTF-8' });
        res.end(content);
      });
      return;
    }
    const ext         = path.extname(filePath).toLowerCase();
    const contentType = MIME_TYPES[ext] || 'application/octet-stream';
    fs.readFile(filePath, (readErr, content) => {
      if (readErr) { res.writeHead(500); res.end('Error al leer el archivo.'); return; }
      res.writeHead(200, { 'Content-Type': contentType });
      res.end(content);
    });
  });
});

server.listen(PORT, () => {
  console.log('------------------------------------------------------------');
  console.log('🔴 SUBASTAS INDEPENDIENTE - CLUB ATLÉTICO INDEPENDIENTE');
  console.log(`🌐 Servidor local listo en:  http://localhost:${PORT}`);
  console.log('📁 Archivos estáticos:       public/');
  console.log('⚡ API:                       api/');
  console.log('🗄️  Base de datos:            MySQL local');
  console.log('------------------------------------------------------------');
  console.log('  Si es la primera vez, ejecutá primero:  node setup-db.js');
  console.log('------------------------------------------------------------');
});
