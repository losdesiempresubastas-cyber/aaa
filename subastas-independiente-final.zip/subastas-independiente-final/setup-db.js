// setup-db.js — Crea las tablas automáticamente al ejecutarlo
// Uso: node setup-db.js

const mysql = require('mysql2/promise');
const fs    = require('fs');
const path  = require('path');

// Cargar .env si existe
const envPath = path.join(__dirname, '.env');
if (fs.existsSync(envPath)) {
  fs.readFileSync(envPath, 'utf8').split('\n').forEach(linea => {
    linea = linea.trim();
    if (!linea || linea.startsWith('#')) return;
    const idx = linea.indexOf('=');
    if (idx > 0) {
      const clave = linea.slice(0, idx).trim();
      const valor = linea.slice(idx + 1).trim();
      if (!process.env[clave]) process.env[clave] = valor;
    }
  });
}

async function main() {
  const conn = await mysql.createConnection({
    host:     process.env.DB_HOST || 'localhost',
    port:     Number(process.env.DB_PORT) || 3306,
    user:     process.env.DB_USER || 'root',
    password: process.env.DB_PASS || '',
    multipleStatements: true
  });

  console.log('✅ Conectado a MySQL.');

  const sql = fs.readFileSync(path.join(__dirname, 'setup-db.sql'), 'utf8');
  await conn.query(sql);

  console.log('✅ Base de datos "subastas_independiente" y tablas creadas correctamente.');
  console.log('   Tablas: usuarios, productos, carrito, favoritos');
  console.log('');
  console.log('Ahora podés iniciar el servidor con:  node server.js');
  await conn.end();
}

main().catch(err => {
  console.error('❌ Error al crear la base de datos:', err.message);
  console.error('   Verificá que MySQL esté corriendo y que las credenciales en .env sean correctas.');
  process.exit(1);
});
