-- Tabla de usuarios
CREATE TABLE IF NOT EXISTS usuarios (
  id               INT AUTO_INCREMENT PRIMARY KEY,
  nombre           VARCHAR(80)  NOT NULL,
  apellido         VARCHAR(80)  NOT NULL,
  fecha_nacimiento DATE,
  mail             VARCHAR(254) NOT NULL UNIQUE,
  direccion        VARCHAR(250) DEFAULT '',
  clave            VARCHAR(255) NOT NULL,
  creado_en        DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Tabla de productos
CREATE TABLE IF NOT EXISTS productos (
  id               INT AUTO_INCREMENT PRIMARY KEY,
  nombre           VARCHAR(100) NOT NULL,
  descripcion      TEXT,
  precio           DECIMAL(12,2) NOT NULL,
  imagen           TEXT,
  imagen_data      MEDIUMBLOB,
  imagen_mime      VARCHAR(50),
  usuario_id       INT,
  vendedor         VARCHAR(200) DEFAULT 'Catálogo de Independiente',
  estado           VARCHAR(20)  DEFAULT 'activo',
  origen           VARCHAR(30)  DEFAULT 'catalogo-original',
  orden_catalogo   INT          DEFAULT 0,
  catalogo_id      INT          UNIQUE,
  creado_en        DATETIME     DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL
);

-- Tabla de carrito
CREATE TABLE IF NOT EXISTS carrito (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id  INT NOT NULL,
  producto_id INT NOT NULL,
  cantidad    INT DEFAULT 1,
  agregado_en DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_carrito (usuario_id, producto_id),
  FOREIGN KEY (usuario_id)  REFERENCES usuarios(id)  ON DELETE CASCADE,
  FOREIGN KEY (producto_id) REFERENCES productos(id) ON DELETE CASCADE
);

-- Tabla de favoritos
CREATE TABLE IF NOT EXISTS favoritos (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id  INT NOT NULL,
  producto_id INT NOT NULL,
  creado_en   DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_favorito (usuario_id, producto_id),
  FOREIGN KEY (usuario_id)  REFERENCES usuarios(id)  ON DELETE CASCADE,
  FOREIGN KEY (producto_id) REFERENCES productos(id) ON DELETE CASCADE
);
