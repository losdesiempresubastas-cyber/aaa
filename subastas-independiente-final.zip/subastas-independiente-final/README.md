# 🔴 Subastas Independiente — Versión Local (MySQL)

Proyecto escolar para CA Independiente. Funciona 100% local, sin Vercel ni MongoDB.

---

## ¿Qué necesitás instalado?

| Programa | Para qué | ¿Tenés que instalarlo? |
|---|---|---|
| **Node.js** | Correr el servidor | Probablemente ya lo tenés |
| **XAMPP** (o MySQL) | La base de datos | Sí, si no lo tenés |

---

## Pasos para arrancar (primera vez)

### 1. Instalar XAMPP
Descargalo de https://www.apachefriends.org/  
Al abrir XAMPP, hace clic en **Start** en la fila de **MySQL**.

### 2. Crear la base de datos
Abrí http://localhost/phpmyadmin en el navegador y:
- Hacé clic en "Nueva" (panel izquierdo)
- Escribí el nombre: subastas_independiente
- Hacé clic en "Crear"
- Entrá a la base de datos, hacé clic en "SQL" y pegá el contenido de setup-db.sql
- Hacé clic en "Continuar"

O con la terminal (si MySQL está andando):
```
node setup-db.js
```

### 3. Configurar el archivo .env
Copiá .env.example y renombralo a .env
Si tu MySQL tiene contraseña, ponela en DB_PASS.

### 4. Iniciar el servidor
Abrí una terminal en esta carpeta y ejecutá:
```
node server.js
```

### 5. Abrir en el navegador
Entrá a: http://localhost:3000

---

## Estructura del proyecto

```
subastas-independiente-final/
├── server.js          <- Servidor Node.js (arranca con "node server.js")
├── setup-db.js        <- Crea las tablas en MySQL automáticamente
├── setup-db.sql       <- SQL para crear las tablas a mano en phpMyAdmin
├── .env.example       <- Configuración (copialo como .env)
├── package.json       <- Lista de librerias usadas
├── lib/
│   ├── db.js          <- Conexión a MySQL
│   ├── auth.js        <- Sistema de sesiones (cookies firmadas)
│   ├── http.js        <- Helpers del servidor
│   └── catalogo.js    <- 25 productos del catalogo oficial
├── api/
│   ├── health.js      <- Estado del servidor
│   ├── auth/          <- Login, registro, perfil, logout
│   ├── productos/     <- Publicar, listar, eliminar articulos
│   │   ├── carrito/   <- Agregar/quitar del carrito
│   │   └── favoritos/ <- Agregar/quitar de favoritos
│   └── imagen/        <- Servir imagenes subidas por usuarios
└── public/            <- Paginas HTML, CSS, JS e imagenes
    ├── prueba1.html   <- Inicio
    ├── Compras.html   <- Tienda
    ├── login.html     <- Login y registro
    ├── Perfil.html    <- Perfil del usuario
    ├── Carrito.html   <- Carrito de compras
    ├── Favoritos.html <- Articulos favoritos
    └── fotos/         <- Imagenes de los productos
```

## Librerias usadas

- mysql2: Conecta Node.js con MySQL. Permite ejecutar consultas SQL de forma segura.
- bcryptjs: Libreria de seguridad para encriptar contraseñas (disponible para usar).
- Node.js built-ins: http, fs, path, url, crypto (vienen con Node.js, sin instalar nada extra).
